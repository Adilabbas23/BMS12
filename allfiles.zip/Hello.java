Class Hello{
publis static void main(string[]args)
       {
         system.out.println("ssuet")
       }
 