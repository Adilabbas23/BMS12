
public class task3 {

}
